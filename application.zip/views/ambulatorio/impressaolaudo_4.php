<link href="<?= base_url() ?>css/style_p.css" rel="stylesheet" type="text/css" />

<BODY>
    <br>
  <p style="text-align: center;"><strong><span style="font-size: large;"><?= $laudo['0']->cabecalho; ?></strong></p>
    <p><?= $laudo['0']->texto; ?></p>




         <p></p>
        <p></p>
        <p></p>
        <p></p>

</BODY>
</HTML>
