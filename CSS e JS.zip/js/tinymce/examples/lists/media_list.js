// This list may be created by a server logic page PHP/ASP/ASPX/JSP in some backend system.
// There flash movies will be displayed as a dropdown in all media dialog if the "media_external_list_url"
// option is defined in TinyMCE init.

var tinyMCEMediaList = [
	// Name, URL
	["Some Flash", "media/sample.swf"],
	["Some Quicktime", "media/sample.mov"],
	["Some AVI", "media/sample.avi"],
	["Some RealMedia", "media/sample.rm"],
	["Some Shockwave", "media/sample.dcr"],
	["Some Video", "media/sample.mp4"],
	["Some FLV", "media/sample.flv"]
];